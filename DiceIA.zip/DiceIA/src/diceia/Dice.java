/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diceia;



/**
 *
 * @author hugojanuario
 */
public class Dice {
    private int numSides;
    private int numDice; //These will be the two main characteristics of the dice that will need editing.

    public Dice(int numOfSides, int numOfDice ){ 
    this.numSides = numOfSides;
    this.numDice = numOfDice;
    }                                //Overloaded constructors for flexibility
    public Dice( ){
    this.numSides = 6;
    this.numDice = 1;
    }
    

  
     


    /*
    loop as many die as you have:   
     generate a random number between 1 and numSides  out += number; end 
     loop return output
    */

  
    
    
    
} 


